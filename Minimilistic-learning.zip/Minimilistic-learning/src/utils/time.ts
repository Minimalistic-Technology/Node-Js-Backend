const durationRegex = /^(\d+)([smhd])$/i;

export const durationToMs = (duration: string): number => {
  const match = durationRegex.exec(duration);
  if (!match) {
    throw new Error(`Invalid duration string "${duration}". Expected format like "15m" or "7d".`);
  }

  const value = Number(match[1]);
  const unit = match[2].toLowerCase();

  switch (unit) {
    case 's':
      return value * 1000;
    case 'm':
      return value * 60 * 1000;
    case 'h':
      return value * 60 * 60 * 1000;
    case 'd':
      return value * 24 * 60 * 60 * 1000;
    default:
      throw new Error(`Unsupported duration unit "${unit}"`);
  }
};


