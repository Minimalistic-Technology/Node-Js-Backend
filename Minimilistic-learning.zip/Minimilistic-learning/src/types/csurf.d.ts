declare module 'csurf' {
  import { RequestHandler } from 'express';

  interface CsurfOptions {
    value?: (req: any) => string;
    ignoreMethods?: string[];
    cookie?: boolean | object;
    sessionKey?: string;
    sessionSecret?: string;
  }

  function csrf(options?: CsurfOptions): RequestHandler & {
    cookie?: CsurfOptions['cookie'];
  };

  export default csrf;
}


