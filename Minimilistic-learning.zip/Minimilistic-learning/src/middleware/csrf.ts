import csrf from 'csurf';
import { env } from '../config/env';

const csrfProtection = csrf({
  cookie: {
    key: '_csrf',
    httpOnly: true,
    secure: env.isProduction,
    sameSite: 'lax',
    path: '/',
    signed: false
  },
  ignoreMethods: ['GET', 'HEAD', 'OPTIONS']
});

export const attachCsrfToken = (
  req: Parameters<typeof csrfProtection>[0],
  res: Parameters<typeof csrfProtection>[1],
  next: Parameters<typeof csrfProtection>[2]
) => {
  if (typeof req.csrfToken === 'function') {
    try {
      const token = req.csrfToken();
      console.log('Generated CSRF Token:', token);
      res.cookie('XSRF-TOKEN', token, {
        secure: env.isProduction,
        sameSite: 'lax'
      });
    } catch {
      // ignore errors generating token for routes that don't require it
    }
  }
  next();
};

export default csrfProtection;

